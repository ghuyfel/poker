package poker.common.deck.cards

object CardSuit {
    val club = 0x2660
    val diamond = 0x2666
    val heart = 0x2665
    val spade = 0x2660
}
