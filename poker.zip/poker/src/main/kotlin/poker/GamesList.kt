package poker

sealed class GamesList {
    object FiveOfKind : GamesList()
}
